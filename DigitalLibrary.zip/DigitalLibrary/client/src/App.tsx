import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { LanguageProvider } from "@/components/LanguageProvider";
import { useAuth } from "@/hooks/useAuth";
import NotFound from "@/pages/not-found";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Library from "@/pages/Library";
import BookReader from "@/pages/BookReader";
import Admin from "@/pages/Admin";
import Profile from "@/pages/Profile";
import EditProfile from "@/pages/EditProfile";
import AboutDevelopers from "@/pages/AboutDevelopers";
import Settings from "@/pages/Settings";

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  return (
    <Switch>
      {isLoading || !isAuthenticated ? (
        <Route path="/" component={Landing} />
      ) : (
        <>
          <Route path="/" component={Home} />
          <Route path="/library" component={Library} />
          <Route path="/reader/:bookId" component={BookReader} />
          <Route path="/admin" component={Admin} />
          <Route path="/profile" component={Profile} />
          <Route path="/profile/edit" component={EditProfile} />
          <Route path="/about-developers" component={AboutDevelopers} />
          <Route path="/favorites" component={() => <div>Favorites page coming soon</div>} />
          <Route path="/reading-list" component={() => <div>Reading list page coming soon</div>} />
          <Route path="/liked" component={() => <div>Liked books page coming soon</div>} />
          <Route path="/upload" component={() => <div>Upload page coming soon</div>} />
          <Route path="/premium" component={() => <div>Premium page coming soon</div>} />
          <Route path="/settings" component={Settings} />
        </>
      )}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <LanguageProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </LanguageProvider>
    </QueryClientProvider>
  );
}

export default App;
