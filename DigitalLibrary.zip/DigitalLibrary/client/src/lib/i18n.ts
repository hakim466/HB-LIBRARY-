// Language translations
export const translations = {
  english: {
    // Header
    searchPlaceholder: "Search books...",
    myAccount: "My Account",
    
    // Navigation
    home: "Home",
    library: "Library",
    favorites: "Favorites",
    readingList: "Reading List",
    liked: "Liked Books",
    upload: "Upload Book",
    premium: "Premium",
    settings: "App Settings",
    aboutDevelopers: "About the Developers",
    adminPanel: "Admin Panel (Bou Bou)",
    logout: "Log Out",
    
    // Home page
    welcomeBack: "Welcome back",
    featuredBooks: "Featured Books",
    currentlyReading: "Currently Reading",
    myCollections: "My Collections",
    discoverBooks: "Discover new books in our library",
    
    // Profile
    profile: "Profile",
    editProfile: "Edit Profile",
    fullName: "Full Name",
    email: "Email",
    premiumMember: "Premium Member",
    joinedOn: "Joined on",
    
    // Settings
    appSettings: "App Settings",
    languageSettings: "Language Settings",
    changeLanguage: "Change Language",
    regionSettings: "Region Settings",
    selectCountry: "Select Country",
    displaySettings: "Display Settings",
    darkMode: "Dark Mode",
    darkModeDesc: "Toggle between light and dark themes",
    notificationSettings: "Notification Settings",
    enableNotifications: "Enable Notifications",
    notificationDesc: "Receive updates about new books and alerts",
    helpSupport: "Help & Support",
    needAssistance: "Need assistance with the website? Our support team is here to help.",
    getHelp: "Get Help & Support",
    saveSettings: "Save Settings",
    settingsSaved: "Settings Saved",
    settingsSavedDesc: "Your preferences have been updated successfully.",
    
    // About Developers
    aboutTitle: "About the Developers",
    meetTeam: "Meet Our Development Team",
    developedBy: "This library was developed by the couple",
    developerNames: "Bouthaina and Hakim",
    fromAlgeria: "from Algeria, both 16 years old.",
    needHelp: "Need Help?",
    contactUs: "If you need assistance with the website, please don't hesitate to contact us:",
    quote: "Building digital solutions to make reading accessible to everyone",
    managedBy: "Library managed by Bou Bou",
    
    // Common
    backToHome: "Back to Home",
    save: "Save",
    cancel: "Cancel",
    loading: "Loading...",
  },
  
  arabic: {
    // Header
    searchPlaceholder: "البحث عن الكتب...",
    myAccount: "حسابي",
    
    // Navigation
    home: "الرئيسية",
    library: "المكتبة",
    favorites: "المفضلة",
    readingList: "قائمة القراءة",
    liked: "الكتب المحبوبة",
    upload: "رفع كتاب",
    premium: "المميز",
    settings: "إعدادات التطبيق",
    aboutDevelopers: "حول المطورين",
    adminPanel: "لوحة الإدارة (بو بو)",
    logout: "تسجيل الخروج",
    
    // Home page
    welcomeBack: "مرحباً بعودتك",
    featuredBooks: "الكتب المميزة",
    currentlyReading: "قراءة حالياً",
    myCollections: "مجموعاتي",
    discoverBooks: "اكتشف كتباً جديدة في مكتبتنا",
    
    // Profile
    profile: "الملف الشخصي",
    editProfile: "تعديل الملف الشخصي",
    fullName: "الاسم الكامل",
    email: "البريد الإلكتروني",
    premiumMember: "عضو مميز",
    joinedOn: "انضم في",
    
    // Settings
    appSettings: "إعدادات التطبيق",
    languageSettings: "إعدادات اللغة",
    changeLanguage: "تغيير اللغة",
    regionSettings: "إعدادات المنطقة",
    selectCountry: "اختر البلد",
    displaySettings: "إعدادات العرض",
    darkMode: "الوضع المظلم",
    darkModeDesc: "التبديل بين الثيمات الفاتحة والمظلمة",
    notificationSettings: "إعدادات الإشعارات",
    enableNotifications: "تفعيل الإشعارات",
    notificationDesc: "تلقي تحديثات حول الكتب الجديدة والتنبيهات",
    helpSupport: "المساعدة والدعم",
    needAssistance: "تحتاج مساعدة مع الموقع؟ فريق الدعم هنا لمساعدتك.",
    getHelp: "الحصول على المساعدة والدعم",
    saveSettings: "حفظ الإعدادات",
    settingsSaved: "تم حفظ الإعدادات",
    settingsSavedDesc: "تم تحديث تفضيلاتك بنجاح.",
    
    // About Developers
    aboutTitle: "حول المطورين",
    meetTeam: "تعرف على فريق التطوير",
    developedBy: "تم تطوير هذه المكتبة من قبل الزوجين",
    developerNames: "بوتينة وحكيم",
    fromAlgeria: "من الجزائر، كلاهما 16 سنة.",
    needHelp: "تحتاج مساعدة؟",
    contactUs: "إذا كنت تحتاج مساعدة مع الموقع، لا تتردد في الاتصال بنا:",
    quote: "بناء حلول رقمية لجعل القراءة متاحة للجميع",
    managedBy: "المكتبة تديرها بو بو",
    
    // Common
    backToHome: "العودة للرئيسية",
    save: "حفظ",
    cancel: "إلغاء",
    loading: "جاري التحميل...",
  },
  
  french: {
    // Header
    searchPlaceholder: "Rechercher des livres...",
    myAccount: "Mon Compte",
    
    // Navigation
    home: "Accueil",
    library: "Bibliothèque",
    favorites: "Favoris",
    readingList: "Liste de Lecture",
    liked: "Livres Aimés",
    upload: "Télécharger un Livre",
    premium: "Premium",
    settings: "Paramètres de l'App",
    aboutDevelopers: "À Propos des Développeurs",
    adminPanel: "Panneau Admin (Bou Bou)",
    logout: "Se Déconnecter",
    
    // Home page
    welcomeBack: "Bon retour",
    featuredBooks: "Livres en Vedette",
    currentlyReading: "Lecture en Cours",
    myCollections: "Mes Collections",
    discoverBooks: "Découvrez de nouveaux livres dans notre bibliothèque",
    
    // Profile
    profile: "Profil",
    editProfile: "Modifier le Profil",
    fullName: "Nom Complet",
    email: "Email",
    premiumMember: "Membre Premium",
    joinedOn: "Rejoint le",
    
    // Settings
    appSettings: "Paramètres de l'Application",
    languageSettings: "Paramètres de Langue",
    changeLanguage: "Changer la Langue",
    regionSettings: "Paramètres de Région",
    selectCountry: "Sélectionner le Pays",
    displaySettings: "Paramètres d'Affichage",
    darkMode: "Mode Sombre",
    darkModeDesc: "Basculer entre les thèmes clair et sombre",
    notificationSettings: "Paramètres de Notification",
    enableNotifications: "Activer les Notifications",
    notificationDesc: "Recevoir des mises à jour sur les nouveaux livres et alertes",
    helpSupport: "Aide et Support",
    needAssistance: "Besoin d'aide avec le site web? Notre équipe de support est là pour vous aider.",
    getHelp: "Obtenir de l'Aide et du Support",
    saveSettings: "Sauvegarder les Paramètres",
    settingsSaved: "Paramètres Sauvegardés",
    settingsSavedDesc: "Vos préférences ont été mises à jour avec succès.",
    
    // About Developers
    aboutTitle: "À Propos des Développeurs",
    meetTeam: "Rencontrez Notre Équipe de Développement",
    developedBy: "Cette bibliothèque a été développée par le couple",
    developerNames: "Bouthaina et Hakim",
    fromAlgeria: "d'Algérie, tous deux âgés de 16 ans.",
    needHelp: "Besoin d'Aide?",
    contactUs: "Si vous avez besoin d'aide avec le site web, n'hésitez pas à nous contacter:",
    quote: "Construire des solutions numériques pour rendre la lecture accessible à tous",
    managedBy: "Bibliothèque gérée par Bou Bou",
    
    // Common
    backToHome: "Retour à l'Accueil",
    save: "Sauvegarder",
    cancel: "Annuler",
    loading: "Chargement...",
  },
  
  spanish: {
    // Header
    searchPlaceholder: "Buscar libros...",
    myAccount: "Mi Cuenta",
    
    // Navigation
    home: "Inicio",
    library: "Biblioteca",
    favorites: "Favoritos",
    readingList: "Lista de Lectura",
    liked: "Libros Gustados",
    upload: "Subir Libro",
    premium: "Premium",
    settings: "Configuración de la App",
    aboutDevelopers: "Acerca de los Desarrolladores",
    adminPanel: "Panel de Admin (Bou Bou)",
    logout: "Cerrar Sesión",
    
    // Home page
    welcomeBack: "Bienvenido de vuelta",
    featuredBooks: "Libros Destacados",
    currentlyReading: "Leyendo Actualmente",
    myCollections: "Mis Colecciones",
    discoverBooks: "Descubre nuevos libros en nuestra biblioteca",
    
    // Profile
    profile: "Perfil",
    editProfile: "Editar Perfil",
    fullName: "Nombre Completo",
    email: "Correo Electrónico",
    premiumMember: "Miembro Premium",
    joinedOn: "Se unió el",
    
    // Settings
    appSettings: "Configuración de la Aplicación",
    languageSettings: "Configuración de Idioma",
    changeLanguage: "Cambiar Idioma",
    regionSettings: "Configuración de Región",
    selectCountry: "Seleccionar País",
    displaySettings: "Configuración de Pantalla",
    darkMode: "Modo Oscuro",
    darkModeDesc: "Alternar entre temas claro y oscuro",
    notificationSettings: "Configuración de Notificaciones",
    enableNotifications: "Habilitar Notificaciones",
    notificationDesc: "Recibir actualizaciones sobre nuevos libros y alertas",
    helpSupport: "Ayuda y Soporte",
    needAssistance: "¿Necesitas ayuda con el sitio web? Nuestro equipo de soporte está aquí para ayudar.",
    getHelp: "Obtener Ayuda y Soporte",
    saveSettings: "Guardar Configuración",
    settingsSaved: "Configuración Guardada",
    settingsSavedDesc: "Tus preferencias han sido actualizadas exitosamente.",
    
    // About Developers
    aboutTitle: "Acerca de los Desarrolladores",
    meetTeam: "Conoce a Nuestro Equipo de Desarrollo",
    developedBy: "Esta biblioteca fue desarrollada por la pareja",
    developerNames: "Bouthaina y Hakim",
    fromAlgeria: "de Argelia, ambos de 16 años.",
    needHelp: "¿Necesitas Ayuda?",
    contactUs: "Si necesitas asistencia con el sitio web, no dudes en contactarnos:",
    quote: "Construyendo soluciones digitales para hacer la lectura accesible para todos",
    managedBy: "Biblioteca administrada por Bou Bou",
    
    // Common
    backToHome: "Volver al Inicio",
    save: "Guardar",
    cancel: "Cancelar",
    loading: "Cargando...",
  }
};

export type Language = keyof typeof translations;

// Language context
import { createContext, useContext } from 'react';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

export const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};

// Translation function
export const getTranslation = (language: Language, key: string): string => {
  const keys = key.split('.');
  let value: any = translations[language];
  
  for (const k of keys) {
    value = value?.[k];
  }
  
  return value || key;
};