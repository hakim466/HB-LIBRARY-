import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Phone, MapPin, Users } from "lucide-react";
import { useLocation } from "wouter";

export default function AboutDevelopers() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="max-w-2xl mx-auto">
            <div className="mb-6">
              <Button 
                variant="ghost" 
                onClick={() => setLocation("/")}
                className="mb-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Home
              </Button>
              <h1 className="text-3xl font-bold font-montserrat text-center">About the Developers</h1>
            </div>

            <Card className="shadow-lg">
              <CardContent className="p-8 text-center">
                <div className="mb-8">
                  <Users className="h-16 w-16 text-primary mx-auto mb-4" />
                  <h2 className="text-2xl font-bold font-montserrat mb-4 text-primary">
                    Meet Our Development Team
                  </h2>
                </div>

                <div className="space-y-6 text-gray-700 leading-relaxed">
                  <p className="text-lg">
                    This library was developed by the couple <strong className="text-primary">Bouthaina and Hakim</strong> from Algeria, both 16 years old.
                  </p>
                  
                  <div className="flex items-center justify-center space-x-2 text-gray-600">
                    <MapPin className="h-4 w-4" />
                    <span>Algeria</span>
                  </div>

                  <div className="bg-primary/10 rounded-lg p-6 my-8">
                    <h3 className="font-semibold text-primary mb-3">Need Help?</h3>
                    <p className="mb-4">
                      If you need assistance with the website, please don't hesitate to contact us:
                    </p>
                    <div className="flex items-center justify-center space-x-2 text-lg font-semibold">
                      <Phone className="h-5 w-5 text-primary" />
                      <a 
                        href="tel:0774197516" 
                        className="text-primary hover:text-primary/80 transition-colors"
                      >
                        0774197516
                      </a>
                    </div>
                  </div>

                  <div className="text-sm text-gray-500 italic">
                    "Building digital solutions to make reading accessible to everyone"
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Footer */}
            <div className="text-center mt-8">
              <p className="text-gray-500 text-sm">
                Library managed by Bou Bou
              </p>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}