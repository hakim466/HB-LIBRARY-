import { useQuery, useMutation } from "@tanstack/react-query";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CheckCircle, XCircle, Users, BookOpen, Star } from "lucide-react";
import type { Book } from "@shared/schema";

export default function Admin() {
  const { toast } = useToast();

  const { data: pendingBooks = [] } = useQuery<Book[]>({
    queryKey: ["/api/admin/books/pending"],
  });

  const { data: stats } = useQuery<{ totalUsers: number; totalBooks: number; totalReviews: number }>({
    queryKey: ["/api/admin/stats"],
  });

  const approveMutation = useMutation({
    mutationFn: (bookId: string) => apiRequest("POST", `/api/admin/books/${bookId}/approve`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/books/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Book Approved",
        description: "The book has been approved and is now visible to users.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to approve the book. Please try again.",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (bookId: string) => apiRequest("DELETE", `/api/books/${bookId}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/books/pending"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/stats"] });
      toast({
        title: "Book Deleted",
        description: "The book has been removed from the platform.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete the book. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleApprove = (bookId: string) => {
    approveMutation.mutate(bookId);
  };

  const handleReject = (bookId: string) => {
    deleteMutation.mutate(bookId);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="mb-8">
            <h1 className="text-3xl font-bold font-montserrat mb-6">Admin Dashboard</h1>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.totalUsers || 0}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Books</CardTitle>
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.totalBooks || 0}</div>
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Reviews</CardTitle>
                  <Star className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats?.totalReviews || 0}</div>
                </CardContent>
              </Card>
            </div>

            {/* Pending Books */}
            <Card>
              <CardHeader>
                <CardTitle className="font-montserrat">Pending Book Approvals</CardTitle>
              </CardHeader>
              <CardContent>
                {pendingBooks.length === 0 ? (
                  <p className="text-gray-600 text-center py-8">No pending books to review.</p>
                ) : (
                  <div className="space-y-4">
                    {pendingBooks.map((book) => (
                      <div key={book.id} className="flex items-center space-x-4 p-4 border rounded-lg">
                        <img
                          src={book.coverImageUrl || "/placeholder-book.png"}
                          alt={book.title}
                          className="w-16 h-24 object-cover rounded"
                        />
                        <div className="flex-1">
                          <h3 className="font-semibold font-montserrat">{book.title}</h3>
                          <p className="text-gray-600">{book.author}</p>
                          <p className="text-sm text-gray-500">{book.genre}</p>
                          <div className="flex items-center space-x-2 mt-2">
                            <Badge variant="outline">
                              Uploaded {new Date(book.createdAt!).toLocaleDateString()}
                            </Badge>
                            {book.fileSize && (
                              <Badge variant="outline">
                                {(book.fileSize / (1024 * 1024)).toFixed(1)} MB
                              </Badge>
                            )}
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button
                            onClick={() => handleApprove(book.id)}
                            disabled={approveMutation.isPending}
                            className="bg-green-600 hover:bg-green-700 text-white"
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Approve
                          </Button>
                          <Button
                            onClick={() => handleReject(book.id)}
                            disabled={deleteMutation.isPending}
                            variant="destructive"
                          >
                            <XCircle className="h-4 w-4 mr-2" />
                            Reject
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </main>
      </div>
    </div>
  );
}
