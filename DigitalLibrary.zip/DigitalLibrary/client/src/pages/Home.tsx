import { useQuery } from "@tanstack/react-query";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import BookCard from "@/components/BookCard";
import PremiumCard from "@/components/PremiumCard";
import BookUpload from "@/components/BookUpload";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Book, Heart, Bookmark, CheckCircle } from "lucide-react";
import type { Book as BookType, ReadingProgress } from "@shared/schema";

export default function Home() {
  const { data: featuredBooks = [] } = useQuery<BookType[]>({
    queryKey: ["/api/books/featured"],
  });

  const { data: currentlyReading = [] } = useQuery<(ReadingProgress & { book: BookType })[]>({
    queryKey: ["/api/reading-progress"],
  });

  const { data: collections = [] } = useQuery({
    queryKey: ["/api/collections"],
  });

  // Mock collection data for display
  const collectionsData = [
    { name: "Favorites", count: 23, icon: Heart, color: "text-red-500", bgColor: "bg-red-100" },
    { name: "To Read", count: 15, icon: Bookmark, color: "text-blue-500", bgColor: "bg-blue-100" },
    { name: "Completed", count: 87, icon: CheckCircle, color: "text-green-500", bgColor: "bg-green-100" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          {/* Hero Section */}
          <section className="mb-8">
            <div className="gradient-primary rounded-xl p-8 text-white relative overflow-hidden">
              <div className="relative z-10">
                <h2 className="text-4xl font-bold mb-4 font-montserrat">
                  Discover Your Next Great Read
                </h2>
                <p className="text-xl opacity-90 mb-6">
                  Access thousands of digital books, share reviews, and connect with fellow readers
                </p>
                <Button 
                  variant="secondary"
                  size="lg"
                  className="bg-white text-primary hover:bg-gray-100"
                >
                  Start Reading
                </Button>
              </div>
            </div>
          </section>

          {/* Featured Books Section */}
          <section className="mb-8">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-2xl font-bold font-montserrat">Featured Books</h3>
              <Button variant="ghost" className="text-primary hover:text-primary/80">
                View All
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {featuredBooks.map((book) => (
                <BookCard key={book.id} book={book} />
              ))}
            </div>
          </section>

          {/* Currently Reading Section */}
          {currentlyReading.length > 0 && (
            <section className="mb-8">
              <h3 className="text-2xl font-bold mb-6 font-montserrat">Continue Reading</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {currentlyReading.map((item) => (
                  <Card key={item.id} className="p-6">
                    <div className="flex items-center space-x-4 mb-4">
                      <img 
                        src={item.book.coverImageUrl || "/placeholder-book.png"} 
                        alt={item.book.title}
                        className="w-12 h-16 object-cover rounded"
                      />
                      <div>
                        <h4 className="font-semibold font-montserrat">{item.book.title}</h4>
                        <p className="text-sm text-gray-600">{item.book.author}</p>
                      </div>
                    </div>
                    <div className="mb-4">
                      <div className="flex justify-between text-sm text-gray-600 mb-1">
                        <span>Progress</span>
                        <span>{item.progressPercentage}%</span>
                      </div>
                      <Progress value={Number(item.progressPercentage)} className="h-2" />
                    </div>
                    <Button 
                      className="w-full bg-primary hover:bg-primary/90"
                      onClick={() => window.location.href = `/reader/${item.book.id}`}
                    >
                      Continue Reading
                    </Button>
                  </Card>
                ))}
              </div>
            </section>
          )}

          {/* Collections Section */}
          <section className="mb-8">
            <h3 className="text-2xl font-bold mb-6 font-montserrat">My Collections</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {collectionsData.map((collection) => (
                <Card key={collection.name} className="p-6 hover:shadow-lg transition-shadow cursor-pointer">
                  <div className="flex items-center space-x-3 mb-4">
                    <div className={`w-12 h-12 ${collection.bgColor} rounded-lg flex items-center justify-center`}>
                      <collection.icon className={`${collection.color} text-xl`} />
                    </div>
                    <div>
                      <h4 className="font-semibold font-montserrat">{collection.name}</h4>
                      <p className="text-sm text-gray-600">{collection.count} books</p>
                    </div>
                  </div>
                  <div className="flex -space-x-2">
                    {/* Mock book covers */}
                    <div className="w-8 h-12 bg-gray-200 rounded border-2 border-white"></div>
                    <div className="w-8 h-12 bg-gray-300 rounded border-2 border-white"></div>
                    <div className="w-8 h-12 bg-gray-400 rounded border-2 border-white"></div>
                    <div className="w-8 h-12 bg-gray-200 rounded border-2 border-white flex items-center justify-center text-xs text-gray-600">
                      +{collection.count - 3}
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </section>

          {/* Upload & Premium Section */}
          <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <BookUpload />
            <PremiumCard />
          </section>
        </main>
      </div>
    </div>
  );
}
