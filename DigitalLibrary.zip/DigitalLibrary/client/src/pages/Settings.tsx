import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useLanguage } from "@/lib/i18n";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { ArrowLeft, Globe, MapPin, Moon, Sun, Bell, HelpCircle } from "lucide-react";
import { useLocation } from "wouter";

export default function Settings() {
  const { user } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { language, setLanguage, t } = useLanguage();
  
  const [country, setCountry] = useState("algeria");
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);

  const languages = [
    { value: "english", label: "English" },
    { value: "arabic", label: "العربية (Arabic)" },
    { value: "french", label: "Français (French)" },
    { value: "spanish", label: "Español (Spanish)" },
  ];

  const countries = [
    { value: "algeria", label: "Algeria" },
    { value: "morocco", label: "Morocco" },
    { value: "tunisia", label: "Tunisia" },
    { value: "egypt", label: "Egypt" },
    { value: "usa", label: "United States" },
    { value: "canada", label: "Canada" },
    { value: "uk", label: "United Kingdom" },
    { value: "france", label: "France" },
  ];

  const handleSaveSettings = () => {
    // In a real implementation, this would save settings to the backend
    toast({
      title: t("settingsSaved"),
      description: t("settingsSavedDesc"),
    });
  };

  const handleHelp = () => {
    // Open help or redirect to support
    toast({
      title: t("helpSupport"),
      description: "For assistance, please contact: 0774197516",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          <div className="max-w-2xl mx-auto">
            <div className="mb-6">
              <Button 
                variant="ghost" 
                onClick={() => setLocation("/")}
                className="mb-4"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                {t("backToHome")}
              </Button>
              <h1 className="text-3xl font-bold font-montserrat">{t("appSettings")}</h1>
            </div>

            <div className="space-y-6">
              {/* Language Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 font-montserrat">
                    <Globe className="h-5 w-5" />
                    <span>{t("languageSettings")}</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="language">{t("changeLanguage")}</Label>
                      <Select value={language} onValueChange={setLanguage}>
                        <SelectTrigger className="w-full mt-2">
                          <SelectValue placeholder={t("changeLanguage")} />
                        </SelectTrigger>
                        <SelectContent>
                          {languages.map((lang) => (
                            <SelectItem key={lang.value} value={lang.value}>
                              {lang.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Region Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 font-montserrat">
                    <MapPin className="h-5 w-5" />
                    <span>Region Settings</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="country">Select Country</Label>
                      <Select value={country} onValueChange={setCountry}>
                        <SelectTrigger className="w-full mt-2">
                          <SelectValue placeholder="Select your country" />
                        </SelectTrigger>
                        <SelectContent>
                          {countries.map((country) => (
                            <SelectItem key={country.value} value={country.value}>
                              {country.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Display Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 font-montserrat">
                    <Sun className="h-5 w-5" />
                    <span>Display Settings</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Dark Mode</Label>
                        <div className="text-sm text-gray-600">
                          Toggle between light and dark themes
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Sun className="h-4 w-4" />
                        <Switch 
                          checked={darkMode} 
                          onCheckedChange={setDarkMode} 
                        />
                        <Moon className="h-4 w-4" />
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Notification Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 font-montserrat">
                    <Bell className="h-5 w-5" />
                    <span>Notification Settings</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="space-y-0.5">
                        <Label>Enable Notifications</Label>
                        <div className="text-sm text-gray-600">
                          Receive updates about new books and alerts
                        </div>
                      </div>
                      <Switch 
                        checked={notifications} 
                        onCheckedChange={setNotifications} 
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Help Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 font-montserrat">
                    <HelpCircle className="h-5 w-5" />
                    <span>Help & Support</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-gray-600">
                      Need assistance with the website? Our support team is here to help.
                    </p>
                    <Button 
                      variant="outline" 
                      onClick={handleHelp}
                      className="w-full"
                    >
                      <HelpCircle className="h-4 w-4 mr-2" />
                      Get Help & Support
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Save Button */}
              <div className="pt-4">
                <Button 
                  onClick={handleSaveSettings}
                  className="w-full bg-primary hover:bg-primary/90"
                  size="lg"
                >
                  Save Settings
                </Button>
              </div>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}