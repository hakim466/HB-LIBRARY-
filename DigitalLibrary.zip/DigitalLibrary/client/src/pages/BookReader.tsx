import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Slider } from "@/components/ui/slider";
import { X, ChevronLeft, ChevronRight, Settings } from "lucide-react";
import type { Book, ReadingProgress } from "@shared/schema";

export default function BookReader() {
  const [match, params] = useRoute("/reader/:bookId");
  const bookId = params?.bookId;
  const [showSidebar, setShowSidebar] = useState(true);
  const [fontSize, setFontSize] = useState(16);
  const [theme, setTheme] = useState("light");
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages] = useState(342); // This would come from the book data

  const { data: book } = useQuery<Book>({
    queryKey: [`/api/books/${bookId}`],
    enabled: !!bookId,
  });

  const { data: progress } = useQuery<ReadingProgress>({
    queryKey: [`/api/reading-progress`, bookId],
    enabled: !!bookId,
  });

  useEffect(() => {
    if (progress) {
      setCurrentPage(progress.currentPage || 1);
    }
  }, [progress]);

  const handleClose = () => {
    window.history.back();
  };

  const progressPercentage = (currentPage / totalPages) * 100;

  const themes = {
    light: "bg-white text-gray-900",
    dark: "bg-gray-900 text-gray-100",
    sepia: "bg-yellow-50 text-gray-800",
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 z-50 flex">
      {/* Sidebar */}
      {showSidebar && (
        <div className="w-80 bg-white overflow-y-auto">
          <div className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="font-bold text-lg font-montserrat">Table of Contents</h3>
              <Button variant="ghost" size="sm" onClick={handleClose}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            {/* Chapter Navigation */}
            <nav className="space-y-2 mb-8">
              <Button variant="default" className="w-full justify-start bg-primary text-white">
                Chapter 1: Introduction
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                Chapter 2: The Journey Begins
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                Chapter 3: Discoveries
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                Chapter 4: Challenges
              </Button>
              <Button variant="ghost" className="w-full justify-start">
                Chapter 5: Resolution
              </Button>
            </nav>

            {/* Reading Settings */}
            <div className="pt-6 border-t border-gray-200">
              <h4 className="font-semibold mb-4 font-montserrat">Reading Settings</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-gray-600 mb-2">Font Size</label>
                  <Slider
                    value={[fontSize]}
                    onValueChange={(value) => setFontSize(value[0])}
                    min={12}
                    max={24}
                    step={1}
                    className="w-full"
                  />
                  <div className="text-xs text-gray-500 mt-1">{fontSize}px</div>
                </div>
                <div>
                  <label className="block text-sm text-gray-600 mb-2">Theme</label>
                  <div className="flex space-x-2">
                    <Button
                      variant={theme === "light" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setTheme("light")}
                      className="w-8 h-8 bg-white border-2 border-primary"
                    />
                    <Button
                      variant={theme === "dark" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setTheme("dark")}
                      className="w-8 h-8 bg-gray-800 border-2 border-gray-300"
                    />
                    <Button
                      variant={theme === "sepia" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setTheme("sepia")}
                      className="w-8 h-8 bg-yellow-50 border-2 border-gray-300"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Reader Content */}
      <div className={`flex-1 overflow-y-auto ${themes[theme as keyof typeof themes]}`}>
        <div className="max-w-3xl mx-auto p-12">
          <h1 className="text-3xl font-bold mb-8 font-montserrat" style={{ fontSize: `${fontSize * 1.5}px` }}>
            {book?.title || "Chapter 1: Introduction"}
          </h1>
          <div className="prose prose-lg max-w-none" style={{ fontSize: `${fontSize}px` }}>
            <p className="leading-relaxed mb-6">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
            </p>
            <p className="leading-relaxed mb-6">
              Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </p>
            <p className="leading-relaxed mb-6">
              Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.
            </p>
            <p className="leading-relaxed mb-6">
              Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet.
            </p>
          </div>
        </div>

        {/* Reading Progress Bar */}
        <div className={`fixed bottom-0 ${showSidebar ? 'left-80' : 'left-0'} right-0 bg-white border-t border-gray-200 p-4`}>
          <div className="max-w-3xl mx-auto flex items-center justify-between">
            <Button variant="ghost" onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}>
              <ChevronLeft className="h-4 w-4 mr-2" />
              Previous
            </Button>
            <div className="flex-1 mx-8">
              <Progress value={progressPercentage} className="h-2 mb-1" />
              <div className="flex justify-between text-sm text-gray-600">
                <span>Page {currentPage} of {totalPages}</span>
                <span>{Math.round(progressPercentage)}% Complete</span>
              </div>
            </div>
            <Button variant="ghost" onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}>
              Next
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        </div>

        {/* Floating Controls */}
        <div className="fixed top-4 right-4 flex space-x-2">
          <Button 
            variant="outline" 
            size="sm"
            onClick={() => setShowSidebar(!showSidebar)}
            className="bg-white"
          >
            <Settings className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="sm" onClick={handleClose} className="bg-white">
            <X className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
