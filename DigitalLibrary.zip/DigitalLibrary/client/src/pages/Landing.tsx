import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { FaFacebook, FaGoogle, FaTwitter } from "react-icons/fa";

export default function Landing() {
  const handleSocialLogin = (provider: string) => {
    window.location.href = '/api/login';
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-purple-50 flex items-center justify-center">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-primary font-montserrat mb-2">HM LIBRARY</h1>
          <p className="text-gray-600 text-lg">Online Book Library Platform</p>
        </div>

        {/* Login Card */}
        <Card className="shadow-2xl">
          <CardContent className="p-8">
            <h2 className="text-2xl font-bold text-center mb-6 font-montserrat">
              Welcome Back
            </h2>
            <p className="text-gray-600 text-center mb-8">
              Sign in to access thousands of books and connect with fellow readers
            </p>

            {/* Social Login Buttons */}
            <div className="space-y-4">
              <Button 
                onClick={() => handleSocialLogin('facebook')}
                className="w-full social-btn-facebook h-12 text-lg"
              >
                <FaFacebook className="w-5 h-5 mr-3" />
                Sign in with Facebook
              </Button>
              
              <Button 
                onClick={() => handleSocialLogin('google')}
                className="w-full social-btn-google h-12 text-lg"
              >
                <FaGoogle className="w-5 h-5 mr-3" />
                Sign in with Gmail
              </Button>
              
              <Button 
                onClick={() => handleSocialLogin('twitter')}
                className="w-full social-btn-twitter h-12 text-lg"
              >
                <FaTwitter className="w-5 h-5 mr-3" />
                Sign in with Twitter
              </Button>
            </div>

            {/* Privacy Notice */}
            <div className="mt-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
              <h4 className="font-semibold text-yellow-800 mb-2">Account Information</h4>
              <p className="text-sm text-yellow-700">
                When you sign in, we securely collect your username, email address, 
                and profile picture for account management and personalization purposes.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Footer */}
        <footer className="text-center mt-8">
          <p className="text-gray-500 text-sm">
            Library managed by Bou Bou
          </p>
        </footer>
      </div>
    </div>
  );
}
