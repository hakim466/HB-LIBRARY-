import { useState, useEffect } from 'react';
import { LanguageContext, Language, getTranslation } from '@/lib/i18n';

interface LanguageProviderProps {
  children: React.ReactNode;
}

export function LanguageProvider({ children }: LanguageProviderProps) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('language');
    return (saved as Language) || 'english';
  });

  useEffect(() => {
    localStorage.setItem('language', language);
    
    // Set document direction for RTL languages
    if (language === 'arabic') {
      document.documentElement.dir = 'rtl';
      document.documentElement.lang = 'ar';
    } else {
      document.documentElement.dir = 'ltr';
      document.documentElement.lang = language === 'english' ? 'en' : 
                                      language === 'french' ? 'fr' : 'es';
    }
  }, [language]);

  const t = (key: string): string => {
    return getTranslation(language, key);
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}