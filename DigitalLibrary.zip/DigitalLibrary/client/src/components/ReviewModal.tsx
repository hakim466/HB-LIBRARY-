import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Star } from "lucide-react";
import type { Book, Review } from "@shared/schema";

interface ReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  book: Book;
}

export default function ReviewModal({ isOpen, onClose, book }: ReviewModalProps) {
  const [rating, setRating] = useState(0);
  const [hoveredRating, setHoveredRating] = useState(0);
  const [reviewText, setReviewText] = useState("");
  const { toast } = useToast();

  const { data: existingReview } = useQuery<Review>({
    queryKey: [`/api/reviews/user/${book.id}`],
    enabled: isOpen,
  });

  const reviewMutation = useMutation({
    mutationFn: (data: { rating: number; reviewText: string; bookId: string }) =>
      apiRequest("POST", "/api/reviews", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/books/${book.id}/reviews`] });
      queryClient.invalidateQueries({ queryKey: ["/api/books"] });
      toast({
        title: "Review Submitted",
        description: "Thank you for your review!",
      });
      onClose();
      setRating(0);
      setReviewText("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Could not submit your review. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleStarClick = (starRating: number) => {
    setRating(starRating);
  };

  const handleSubmit = () => {
    if (rating === 0) {
      toast({
        title: "Rating Required",
        description: "Please select a rating before submitting.",
        variant: "destructive",
      });
      return;
    }

    reviewMutation.mutate({
      rating,
      reviewText,
      bookId: book.id,
    });
  };

  const renderStars = () => {
    const stars = [];
    for (let i = 1; i <= 5; i++) {
      const isFilled = i <= (hoveredRating || rating);
      stars.push(
        <button
          key={i}
          type="button"
          className="focus:outline-none"
          onClick={() => handleStarClick(i)}
          onMouseEnter={() => setHoveredRating(i)}
          onMouseLeave={() => setHoveredRating(0)}
        >
          <Star
            className={`h-8 w-8 transition-colors cursor-pointer ${
              isFilled ? "fill-yellow-400 text-yellow-400" : "text-gray-300 hover:text-yellow-400"
            }`}
          />
        </button>
      );
    }
    return stars;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="font-montserrat">Rate & Review</DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6">
          <div className="flex items-center space-x-4">
            <img
              src={book.coverImageUrl || "/placeholder-book.png"}
              alt={book.title}
              className="w-16 h-24 object-cover rounded"
            />
            <div>
              <h4 className="font-semibold font-montserrat">{book.title}</h4>
              <p className="text-sm text-gray-600">{book.author}</p>
            </div>
          </div>

          <div>
            <Label className="text-sm font-semibold mb-2 block">Your Rating</Label>
            <div className="flex space-x-1">
              {renderStars()}
            </div>
          </div>

          <div>
            <Label htmlFor="review-text" className="text-sm font-semibold mb-2 block">
              Your Review
            </Label>
            <Textarea
              id="review-text"
              rows={4}
              placeholder="Share your thoughts about this book..."
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
            />
          </div>

          <div className="flex space-x-3">
            <Button variant="outline" onClick={onClose} className="flex-1">
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={reviewMutation.isPending || rating === 0}
              className="flex-1 bg-primary hover:bg-primary/90"
            >
              {reviewMutation.isPending ? "Submitting..." : "Submit Review"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
