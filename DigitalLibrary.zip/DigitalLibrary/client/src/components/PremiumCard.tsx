import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { initiateBinancePayment } from "@/lib/binance";
import { Check, Crown } from "lucide-react";
import { FaBitcoin } from "react-icons/fa";
import type { Subscription } from "@shared/schema";

export default function PremiumCard() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const { toast } = useToast();

  const { data: subscription } = useQuery<Subscription>({
    queryKey: ["/api/subscription"],
  });

  const subscriptionMutation = useMutation({
    mutationFn: (data: { planType: string; paymentMethod: string; transactionId: string; amount: string }) =>
      apiRequest("POST", "/api/subscription", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/subscription"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Premium Activated!",
        description: "Welcome to BookVerse Premium! Enjoy unlimited access.",
      });
      setIsModalOpen(false);
    },
    onError: () => {
      toast({
        title: "Subscription Failed",
        description: "Could not activate your premium subscription. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleUpgrade = async (planType: "monthly" | "yearly") => {
    try {
      const amount = planType === "monthly" ? "9.99" : "99.99";
      const paymentResult = await initiateBinancePayment(amount, planType);
      
      if (paymentResult.success) {
        const endDate = new Date();
        if (planType === "monthly") {
          endDate.setMonth(endDate.getMonth() + 1);
        } else {
          endDate.setFullYear(endDate.getFullYear() + 1);
        }

        subscriptionMutation.mutate({
          planType,
          paymentMethod: "binance",
          transactionId: paymentResult.transactionId!,
          amount,
        });
      } else {
        toast({
          title: "Payment Failed",
          description: paymentResult.error || "Payment could not be processed.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Payment Error",
        description: "An error occurred during payment processing.",
        variant: "destructive",
      });
    }
  };

  const features = [
    "Unlimited downloads",
    "Ad-free reading experience",
    "Early access to new releases",
    "Premium author content",
    "Advanced reading analytics",
    "Priority customer support",
  ];

  if (subscription?.status === "active") {
    return (
      <Card className="gradient-gold text-white">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2 font-montserrat">
            <Crown className="h-6 w-6" />
            <span>Premium Active</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="mb-4">
            You're enjoying all premium features! Your subscription is active until{" "}
            {new Date(subscription.endDate).toLocaleDateString()}.
          </p>
          <Badge variant="secondary" className="text-yellow-800">
            {subscription.planType === "monthly" ? "Monthly Plan" : "Yearly Plan"}
          </Badge>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="gradient-gold text-white">
      <CardHeader>
        <CardTitle className="font-montserrat">Upgrade to Premium</CardTitle>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2 mb-6">
          {features.slice(0, 4).map((feature, index) => (
            <li key={index} className="flex items-center space-x-2 text-sm">
              <Check className="h-4 w-4" />
              <span>{feature}</span>
            </li>
          ))}
        </ul>
        
        <Dialog open={isModalOpen} onOpenChange={setIsModalOpen}>
          <DialogTrigger asChild>
            <Button className="w-full bg-white text-orange-500 hover:bg-gray-100 font-semibold">
              <FaBitcoin className="mr-2 h-4 w-4" />
              Upgrade with Crypto
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle className="font-montserrat flex items-center space-x-2">
                <Crown className="h-6 w-6 text-yellow-500" />
                <span>Choose Your Plan</span>
              </DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="space-y-3">
                <h4 className="font-semibold">Premium Features:</h4>
                <ul className="space-y-1 text-sm text-gray-600">
                  {features.map((feature, index) => (
                    <li key={index} className="flex items-center space-x-2">
                      <Check className="h-4 w-4 text-green-500" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="space-y-3">
                <Button
                  onClick={() => handleUpgrade("monthly")}
                  disabled={subscriptionMutation.isPending}
                  className="w-full bg-primary hover:bg-primary/90 flex items-center justify-between"
                >
                  <span>Monthly Plan</span>
                  <span className="font-bold">$9.99/month</span>
                </Button>
                
                <Button
                  onClick={() => handleUpgrade("yearly")}
                  disabled={subscriptionMutation.isPending}
                  className="w-full bg-green-600 hover:bg-green-700 flex items-center justify-between"
                >
                  <span>Yearly Plan</span>
                  <div className="text-right">
                    <div className="font-bold">$99.99/year</div>
                    <div className="text-xs opacity-90">Save 17%</div>
                  </div>
                </Button>
              </div>

              <p className="text-xs text-gray-500 text-center">
                Secure payments powered by Binance Pay. Cancel anytime.
              </p>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
