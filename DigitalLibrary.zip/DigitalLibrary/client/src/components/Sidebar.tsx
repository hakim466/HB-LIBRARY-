import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Home, Book, Heart, Bookmark, Star, Upload, Crown, Settings, Users } from "lucide-react";
import { Link, useLocation } from "wouter";

export default function Sidebar() {
  const { user } = useAuth();
  const [location] = useLocation();

  const navItems = [
    { href: "/", icon: Home, label: "Dashboard" },
    { href: "/library", icon: Book, label: "My Library" },
    { href: "/favorites", icon: Heart, label: "Favorites" },
    { href: "/reading-list", icon: Bookmark, label: "Reading List" },
    { href: "/reviews", icon: Star, label: "Reviews" },
    { href: "/upload", icon: Upload, label: "Upload Book" },
    { href: "/premium", icon: Crown, label: "Premium" },
  ];

  return (
    <aside className="hidden lg:block w-64 bg-white shadow-lg">
      <div className="p-6">
        {/* User Profile Card */}
        <Card className="gradient-primary text-white mb-6">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3 mb-3">
              <Avatar className="h-12 w-12 border-2 border-white">
                <AvatarImage 
                  src={user?.profileImageUrl || ""} 
                  alt={user?.firstName || "User"} 
                />
                <AvatarFallback className="bg-white text-primary font-semibold">
                  {user?.firstName?.[0] || user?.email?.[0] || "U"}
                </AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-semibold font-montserrat">
                  {user?.firstName && user?.lastName 
                    ? `${user.firstName} ${user.lastName}`
                    : user?.email || "User"
                  }
                </h3>
                <p className="text-sm opacity-90">{user?.email}</p>
                {user?.isPremium && (
                  <Badge variant="secondary" className="mt-1 text-xs">
                    Premium
                  </Badge>
                )}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="text-center">
                <div className="font-semibold">0</div>
                <div className="opacity-80">Books Read</div>
              </div>
              <div className="text-center">
                <div className="font-semibold">0</div>
                <div className="opacity-80">Reviews</div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Navigation Menu */}
        <nav className="space-y-2">
          {navItems.map((item) => {
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <a className={`sidebar-nav-item ${isActive ? 'active' : ''}`}>
                  <item.icon className="h-5 w-5" />
                  <span>{item.label}</span>
                </a>
              </Link>
            );
          })}
        </nav>
        
        {/* Admin Panel (conditional) */}
        {user?.isAdmin && (
          <div className="mt-8 pt-6 border-t border-gray-200">
            <h4 className="font-semibold text-sm text-gray-600 mb-3 font-montserrat">
              ADMIN CONTROLS
            </h4>
            <nav className="space-y-2">
              <Link href="/admin">
                <a className="flex items-center space-x-3 p-3 rounded-lg hover:bg-red-50 text-red-600 transition-colors">
                  <Settings className="h-5 w-5" />
                  <span>Manage Content</span>
                </a>
              </Link>
              <Link href="/admin/users">
                <a className="flex items-center space-x-3 p-3 rounded-lg hover:bg-red-50 text-red-600 transition-colors">
                  <Users className="h-5 w-5" />
                  <span>User Management</span>
                </a>
              </Link>
            </nav>
          </div>
        )}
      </div>
    </aside>
  );
}
