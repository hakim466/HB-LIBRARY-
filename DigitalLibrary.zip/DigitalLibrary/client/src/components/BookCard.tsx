import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import ReviewModal from "./ReviewModal";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Heart, Download, Star, BookOpen } from "lucide-react";
import type { Book } from "@shared/schema";

interface BookCardProps {
  book: Book;
}

export default function BookCard({ book }: BookCardProps) {
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [isFavorited, setIsFavorited] = useState(false);
  const { toast } = useToast();

  const downloadMutation = useMutation({
    mutationFn: () => apiRequest("POST", `/api/books/${book.id}/download`),
    onSuccess: () => {
      toast({
        title: "Download Started",
        description: "Your book download has begun.",
      });
    },
    onError: () => {
      toast({
        title: "Download Failed",
        description: "Could not download the book. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFavorite = () => {
    setIsFavorited(!isFavorited);
    // TODO: Implement actual favorite API call
  };

  const handleDownload = () => {
    downloadMutation.mutate();
  };

  const handleRead = () => {
    window.location.href = `/reader/${book.id}`;
  };

  const renderStars = (rating: number) => {
    const stars = [];
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;

    for (let i = 0; i < fullStars; i++) {
      stars.push(<Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />);
    }

    if (hasHalfStar) {
      stars.push(<Star key="half" className="h-4 w-4 fill-yellow-400/50 text-yellow-400" />);
    }

    const remainingStars = 5 - Math.ceil(rating);
    for (let i = 0; i < remainingStars; i++) {
      stars.push(<Star key={`empty-${i}`} className="h-4 w-4 text-gray-300" />);
    }

    return stars;
  };

  return (
    <>
      <Card className="book-card group">
        <div className="relative">
          <img
            src={book.coverImageUrl || "/placeholder-book.png"}
            alt={book.title}
            className="w-full h-48 object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center space-x-2">
            <Button size="sm" onClick={handleRead} className="bg-primary hover:bg-primary/90">
              <BookOpen className="h-4 w-4 mr-1" />
              Read
            </Button>
            {book.fileUrl && (
              <Button 
                size="sm" 
                variant="secondary" 
                onClick={handleDownload}
                disabled={downloadMutation.isPending}
              >
                <Download className="h-4 w-4 mr-1" />
                Download
              </Button>
            )}
          </div>
        </div>
        <CardContent className="p-4">
          <h4 className="font-semibold font-montserrat mb-2 line-clamp-2">
            {book.title}
          </h4>
          <p className="text-sm text-gray-600 mb-2">{book.author}</p>
          {book.genre && (
            <Badge variant="outline" className="text-xs mb-2">
              {book.genre}
            </Badge>
          )}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-1">
              <div className="flex">
                {book.averageRating ? renderStars(Number(book.averageRating)) : (
                  Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 text-gray-300" />
                  ))
                )}
              </div>
              <span className="text-sm text-gray-600">
                {book.averageRating ? Number(book.averageRating).toFixed(1) : "—"}
              </span>
              {book.totalRatings && book.totalRatings > 0 && (
                <span className="text-xs text-gray-500">({book.totalRatings})</span>
              )}
            </div>
            <div className="flex space-x-1">
              <Button
                variant="ghost"
                size="sm"
                onClick={handleFavorite}
                className={`p-1 ${isFavorited ? 'text-red-500' : 'text-gray-400'}`}
              >
                <Heart className={`h-4 w-4 ${isFavorited ? 'fill-current' : ''}`} />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowReviewModal(true)}
                className="p-1 text-gray-400 hover:text-primary"
              >
                <Star className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <ReviewModal
        isOpen={showReviewModal}
        onClose={() => setShowReviewModal(false)}
        book={book}
      />
    </>
  );
}
