import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Search, Menu, LogOut, User, Settings, Home, BookOpen, Heart, Bookmark, Star, Upload, Crown, Users } from "lucide-react";
import { useLocation } from "wouter";

export default function Header() {
  const { user } = useAuth();
  const [location, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState("");

  const handleLogout = () => {
    window.location.href = '/api/logout';
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setLocation(`/library?search=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const menuItems = [
    { href: "/", icon: Home, label: "Home" },
    { href: "/library", icon: BookOpen, label: "My Library" },
    { href: "/favorites", icon: Heart, label: "Saved Books" },
    { href: "/reading-list", icon: Bookmark, label: "Read Books" },
    { href: "/liked", icon: Star, label: "Liked Books" },
    { href: "/upload", icon: Upload, label: "Upload Book ($0.99)" },
    { href: "/premium", icon: Crown, label: "Premium" },
  ];

  return (
    <header className="bg-white shadow-md sticky top-0 z-40">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button onClick={() => setLocation("/")} className="focus:outline-none">
              <h1 className="text-2xl font-bold text-primary font-montserrat cursor-pointer">
                HM LIBRARY
              </h1>
            </button>
            
            {/* Welcome Message */}
            {user && (
              <div className="hidden md:block">
                <p className="text-gray-600">
                  Welcome back, <span className="font-semibold text-primary">
                    {user.firstName || user.email?.split('@')[0]}
                  </span>!
                </p>
              </div>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Search Bar */}
            <form onSubmit={handleSearch} className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                type="text"
                placeholder="Find books or titles..."
                className="w-64 pl-10"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </form>
            
            {/* User Avatar - Clickable */}
            <button 
              onClick={() => setLocation("/profile")}
              className="focus:outline-none focus:ring-2 focus:ring-primary focus:ring-offset-2 rounded-full"
            >
              <Avatar className="h-8 w-8 hover:opacity-80 transition-opacity">
                <AvatarImage 
                  src={user?.profileImageUrl || ""} 
                  alt={user?.firstName || "User"} 
                />
                <AvatarFallback className="bg-primary text-white text-sm">
                  {user?.firstName?.[0] || user?.email?.[0] || "U"}
                </AvatarFallback>
              </Avatar>
            </button>
            
            {/* Three-Bar Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="p-2">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-80">
                <SheetHeader>
                  <SheetTitle className="font-montserrat">Menu</SheetTitle>
                </SheetHeader>
                
                <div className="mt-6 space-y-6">
                  {/* My Account Section */}
                  <div>
                    <h3 className="font-semibold text-gray-800 mb-3 font-montserrat">My Account</h3>
                    <div className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg mb-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage 
                          src={user?.profileImageUrl || ""} 
                          alt={user?.firstName || "User"} 
                        />
                        <AvatarFallback className="bg-primary text-white">
                          {user?.firstName?.[0] || user?.email?.[0] || "U"}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-semibold">{user?.firstName && user?.lastName 
                          ? `${user.firstName} ${user.lastName}` 
                          : user?.email || "User"}</p>
                        <p className="text-sm text-gray-600">{user?.email}</p>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      {/* Edit Profile button removed as requested */}
                    </div>
                  </div>

                  {/* Navigation */}
                  <div>
                    <h3 className="font-semibold text-gray-800 mb-3 font-montserrat">Navigation</h3>
                    <div className="space-y-1">
                      {menuItems.map((item) => (
                        <Button
                          key={item.href}
                          variant="ghost"
                          className={`w-full justify-start ${location === item.href ? 'bg-primary text-white hover:bg-primary/90' : ''}`}
                          onClick={() => setLocation(item.href)}
                        >
                          <item.icon className="mr-3 h-4 w-4" />
                          {item.label}
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Settings */}
                  <div>
                    <h3 className="font-semibold text-gray-800 mb-3 font-montserrat">Settings</h3>
                    <div className="space-y-1">
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start"
                        onClick={() => setLocation("/settings")}
                      >
                        <Settings className="mr-3 h-4 w-4" />
                        App Settings
                      </Button>
                      
                      <Button 
                        variant="ghost" 
                        className="w-full justify-start"
                        onClick={() => setLocation("/about-developers")}
                      >
                        <User className="mr-3 h-4 w-4" />
                        About the Developers
                      </Button>
                      
                      {user?.isAdmin && (
                        <Button
                          variant="ghost"
                          className="w-full justify-start text-red-600 hover:bg-red-50"
                          onClick={() => setLocation("/admin")}
                        >
                          <Settings className="mr-3 h-4 w-4" />
                          Admin Panel (Bou Bou)
                        </Button>
                      )}
                      
                      <Button
                        variant="ghost"
                        className="w-full justify-start text-red-600 hover:bg-red-50"
                        onClick={handleLogout}
                      >
                        <LogOut className="mr-3 h-4 w-4" />
                        Log Out
                      </Button>
                    </div>
                  </div>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
