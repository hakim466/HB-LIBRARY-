import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertBookSchema, insertCollectionSchema, insertReviewSchema, insertReadingProgressSchema, insertSubscriptionSchema } from "@shared/schema";
import multer from "multer";
import path from "path";
import fs from "fs";

// Configure multer for file uploads
const upload = multer({
  dest: "uploads/",
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.pdf', '.epub', '.mobi', '.txt'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type. Only PDF, EPUB, MOBI, and TXT files are allowed.'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Book routes
  app.get('/api/books', async (req, res) => {
    try {
      const { limit = '20', offset = '0', search } = req.query;
      const books = await storage.getBooks(
        parseInt(limit as string),
        parseInt(offset as string),
        search as string
      );
      res.json(books);
    } catch (error) {
      console.error("Error fetching books:", error);
      res.status(500).json({ message: "Failed to fetch books" });
    }
  });

  app.get('/api/books/featured', async (req, res) => {
    try {
      const books = await storage.getFeaturedBooks();
      res.json(books);
    } catch (error) {
      console.error("Error fetching featured books:", error);
      res.status(500).json({ message: "Failed to fetch featured books" });
    }
  });

  app.get('/api/books/:id', async (req, res) => {
    try {
      const book = await storage.getBook(req.params.id);
      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }
      res.json(book);
    } catch (error) {
      console.error("Error fetching book:", error);
      res.status(500).json({ message: "Failed to fetch book" });
    }
  });

  app.post('/api/books', isAuthenticated, upload.single('file'), async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const bookData = insertBookSchema.parse({
        ...req.body,
        uploadedBy: userId,
        fileUrl: req.file ? `/uploads/${req.file.filename}` : undefined,
        fileSize: req.file ? req.file.size : undefined,
      });

      const book = await storage.createBook(bookData);
      res.json(book);
    } catch (error) {
      console.error("Error creating book:", error);
      res.status(500).json({ message: "Failed to create book" });
    }
  });

  app.post('/api/books/:id/download', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      const book = await storage.getBook(req.params.id);

      if (!book) {
        return res.status(404).json({ message: "Book not found" });
      }

      if (!book.fileUrl) {
        return res.status(404).json({ message: "File not available" });
      }

      // Check if user has premium for unlimited downloads
      const subscription = await storage.getUserSubscription(userId);
      const isPremium = user?.isPremium || subscription?.status === 'active';

      if (!isPremium) {
        // Implement download limit logic for free users
        // For now, allow 3 downloads per day
      }

      await storage.incrementDownloadCount(req.params.id);
      
      const filePath = path.join(process.cwd(), book.fileUrl);
      if (fs.existsSync(filePath)) {
        res.download(filePath, `${book.title}.${path.extname(book.fileUrl)}`);
      } else {
        res.status(404).json({ message: "File not found" });
      }
    } catch (error) {
      console.error("Error downloading book:", error);
      res.status(500).json({ message: "Failed to download book" });
    }
  });

  // Collection routes
  app.get('/api/collections', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const collections = await storage.getUserCollections(userId);
      res.json(collections);
    } catch (error) {
      console.error("Error fetching collections:", error);
      res.status(500).json({ message: "Failed to fetch collections" });
    }
  });

  app.post('/api/collections', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const collectionData = insertCollectionSchema.parse({
        ...req.body,
        userId,
      });

      const collection = await storage.createCollection(collectionData);
      res.json(collection);
    } catch (error) {
      console.error("Error creating collection:", error);
      res.status(500).json({ message: "Failed to create collection" });
    }
  });

  app.get('/api/collections/:id/books', async (req, res) => {
    try {
      const books = await storage.getBooksInCollection(req.params.id);
      res.json(books);
    } catch (error) {
      console.error("Error fetching collection books:", error);
      res.status(500).json({ message: "Failed to fetch collection books" });
    }
  });

  app.post('/api/collections/:collectionId/books/:bookId', isAuthenticated, async (req, res) => {
    try {
      const { collectionId, bookId } = req.params;
      const bookCollection = await storage.addBookToCollection(bookId, collectionId);
      res.json(bookCollection);
    } catch (error) {
      console.error("Error adding book to collection:", error);
      res.status(500).json({ message: "Failed to add book to collection" });
    }
  });

  app.delete('/api/collections/:collectionId/books/:bookId', isAuthenticated, async (req, res) => {
    try {
      const { collectionId, bookId } = req.params;
      const success = await storage.removeBookFromCollection(bookId, collectionId);
      if (success) {
        res.json({ message: "Book removed from collection" });
      } else {
        res.status(404).json({ message: "Book not found in collection" });
      }
    } catch (error) {
      console.error("Error removing book from collection:", error);
      res.status(500).json({ message: "Failed to remove book from collection" });
    }
  });

  // Reading progress routes
  app.get('/api/reading-progress', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const currentlyReading = await storage.getCurrentlyReading(userId);
      res.json(currentlyReading);
    } catch (error) {
      console.error("Error fetching reading progress:", error);
      res.status(500).json({ message: "Failed to fetch reading progress" });
    }
  });

  app.post('/api/reading-progress', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const progressData = insertReadingProgressSchema.parse({
        ...req.body,
        userId,
      });

      const progress = await storage.updateReadingProgress(progressData);
      res.json(progress);
    } catch (error) {
      console.error("Error updating reading progress:", error);
      res.status(500).json({ message: "Failed to update reading progress" });
    }
  });

  // Review routes
  app.get('/api/books/:bookId/reviews', async (req, res) => {
    try {
      const reviews = await storage.getBookReviews(req.params.bookId);
      res.json(reviews);
    } catch (error) {
      console.error("Error fetching reviews:", error);
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  app.post('/api/reviews', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const reviewData = insertReviewSchema.parse({
        ...req.body,
        userId,
      });

      const review = await storage.createReview(reviewData);
      res.json(review);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ message: "Failed to create review" });
    }
  });

  // Premium subscription routes
  app.get('/api/subscription', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const subscription = await storage.getUserSubscription(userId);
      res.json(subscription);
    } catch (error) {
      console.error("Error fetching subscription:", error);
      res.status(500).json({ message: "Failed to fetch subscription" });
    }
  });

  app.post('/api/subscription', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const subscriptionData = insertSubscriptionSchema.parse({
        ...req.body,
        userId,
      });

      const subscription = await storage.createSubscription(subscriptionData);
      res.json(subscription);
    } catch (error) {
      console.error("Error creating subscription:", error);
      res.status(500).json({ message: "Failed to create subscription" });
    }
  });

  // Admin routes
  app.get('/api/admin/books/pending', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const pendingBooks = await storage.getPendingBooks();
      res.json(pendingBooks);
    } catch (error) {
      console.error("Error fetching pending books:", error);
      res.status(500).json({ message: "Failed to fetch pending books" });
    }
  });

  app.post('/api/admin/books/:id/approve', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const success = await storage.approveBook(req.params.id);
      if (success) {
        res.json({ message: "Book approved" });
      } else {
        res.status(404).json({ message: "Book not found" });
      }
    } catch (error) {
      console.error("Error approving book:", error);
      res.status(500).json({ message: "Failed to approve book" });
    }
  });

  app.get('/api/admin/stats', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      
      if (!user?.isAdmin) {
        return res.status(403).json({ message: "Admin access required" });
      }

      const stats = await storage.getUserStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching stats:", error);
      res.status(500).json({ message: "Failed to fetch stats" });
    }
  });

  // Serve uploaded files
  app.use('/uploads', (req, res, next) => {
    // Add authentication check for file access
    const filePath = path.join(process.cwd(), 'uploads', req.path);
    if (fs.existsSync(filePath)) {
      res.sendFile(filePath);
    } else {
      res.status(404).json({ message: "File not found" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
