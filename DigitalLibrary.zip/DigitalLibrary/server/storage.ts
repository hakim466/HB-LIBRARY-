import {
  users,
  books,
  collections,
  bookCollections,
  readingProgress,
  reviews,
  subscriptions,
  type User,
  type UpsertUser,
  type Book,
  type InsertBook,
  type Collection,
  type InsertCollection,
  type BookCollection,
  type ReadingProgress,
  type InsertReadingProgress,
  type Review,
  type InsertReview,
  type Subscription,
  type InsertSubscription,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, and, sql, avg, count, like, or } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Book operations
  getBooks(limit?: number, offset?: number, search?: string): Promise<Book[]>;
  getBook(id: string): Promise<Book | undefined>;
  getFeaturedBooks(): Promise<Book[]>;
  createBook(book: InsertBook): Promise<Book>;
  updateBook(id: string, book: Partial<InsertBook>): Promise<Book | undefined>;
  deleteBook(id: string): Promise<boolean>;
  approveBook(id: string): Promise<boolean>;
  incrementDownloadCount(id: string): Promise<void>;
  
  // Collection operations
  getUserCollections(userId: string): Promise<Collection[]>;
  getCollection(id: string): Promise<Collection | undefined>;
  createCollection(collection: InsertCollection): Promise<Collection>;
  addBookToCollection(bookId: string, collectionId: string): Promise<BookCollection>;
  removeBookFromCollection(bookId: string, collectionId: string): Promise<boolean>;
  getBooksInCollection(collectionId: string): Promise<Book[]>;
  
  // Reading progress operations
  getReadingProgress(userId: string, bookId: string): Promise<ReadingProgress | undefined>;
  updateReadingProgress(progress: InsertReadingProgress): Promise<ReadingProgress>;
  getCurrentlyReading(userId: string): Promise<(ReadingProgress & { book: Book })[]>;
  
  // Review operations
  getBookReviews(bookId: string): Promise<(Review & { user: User })[]>;
  getUserReview(userId: string, bookId: string): Promise<Review | undefined>;
  createReview(review: InsertReview): Promise<Review>;
  updateReview(id: string, review: Partial<InsertReview>): Promise<Review | undefined>;
  deleteReview(id: string): Promise<boolean>;
  
  // Premium subscription operations
  getUserSubscription(userId: string): Promise<Subscription | undefined>;
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  updateSubscription(id: string, subscription: Partial<InsertSubscription>): Promise<Subscription | undefined>;
  
  // Admin operations
  getPendingBooks(): Promise<Book[]>;
  getUserStats(): Promise<{ totalUsers: number; totalBooks: number; totalReviews: number }>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Book operations
  async getBooks(limit = 20, offset = 0, search?: string): Promise<Book[]> {
    let query = db.select().from(books).where(eq(books.isApproved, true));
    
    if (search) {
      query = query.where(
        or(
          like(books.title, `%${search}%`),
          like(books.author, `%${search}%`),
          like(books.genre, `%${search}%`)
        )
      );
    }
    
    return query.orderBy(desc(books.createdAt)).limit(limit).offset(offset);
  }

  async getBook(id: string): Promise<Book | undefined> {
    const [book] = await db.select().from(books).where(eq(books.id, id));
    return book;
  }

  async getFeaturedBooks(): Promise<Book[]> {
    return db.select().from(books)
      .where(eq(books.isApproved, true))
      .orderBy(desc(books.averageRating), desc(books.totalRatings))
      .limit(8);
  }

  async createBook(book: InsertBook): Promise<Book> {
    const [newBook] = await db.insert(books).values(book).returning();
    return newBook;
  }

  async updateBook(id: string, book: Partial<InsertBook>): Promise<Book | undefined> {
    const [updatedBook] = await db
      .update(books)
      .set({ ...book, updatedAt: new Date() })
      .where(eq(books.id, id))
      .returning();
    return updatedBook;
  }

  async deleteBook(id: string): Promise<boolean> {
    const result = await db.delete(books).where(eq(books.id, id));
    return result.rowCount > 0;
  }

  async approveBook(id: string): Promise<boolean> {
    const [updatedBook] = await db
      .update(books)
      .set({ isApproved: true, updatedAt: new Date() })
      .where(eq(books.id, id))
      .returning();
    return !!updatedBook;
  }

  async incrementDownloadCount(id: string): Promise<void> {
    await db
      .update(books)
      .set({ downloadCount: sql`${books.downloadCount} + 1` })
      .where(eq(books.id, id));
  }

  // Collection operations
  async getUserCollections(userId: string): Promise<Collection[]> {
    return db.select().from(collections).where(eq(collections.userId, userId));
  }

  async getCollection(id: string): Promise<Collection | undefined> {
    const [collection] = await db.select().from(collections).where(eq(collections.id, id));
    return collection;
  }

  async createCollection(collection: InsertCollection): Promise<Collection> {
    const [newCollection] = await db.insert(collections).values(collection).returning();
    return newCollection;
  }

  async addBookToCollection(bookId: string, collectionId: string): Promise<BookCollection> {
    const [bookCollection] = await db
      .insert(bookCollections)
      .values({ bookId, collectionId })
      .returning();
    return bookCollection;
  }

  async removeBookFromCollection(bookId: string, collectionId: string): Promise<boolean> {
    const result = await db
      .delete(bookCollections)
      .where(and(eq(bookCollections.bookId, bookId), eq(bookCollections.collectionId, collectionId)));
    return result.rowCount > 0;
  }

  async getBooksInCollection(collectionId: string): Promise<Book[]> {
    return db
      .select({
        id: books.id,
        title: books.title,
        author: books.author,
        description: books.description,
        coverImageUrl: books.coverImageUrl,
        fileUrl: books.fileUrl,
        fileSize: books.fileSize,
        pageCount: books.pageCount,
        isbn: books.isbn,
        genre: books.genre,
        publishedYear: books.publishedYear,
        uploadedBy: books.uploadedBy,
        isApproved: books.isApproved,
        averageRating: books.averageRating,
        totalRatings: books.totalRatings,
        downloadCount: books.downloadCount,
        createdAt: books.createdAt,
        updatedAt: books.updatedAt,
      })
      .from(books)
      .innerJoin(bookCollections, eq(books.id, bookCollections.bookId))
      .where(eq(bookCollections.collectionId, collectionId));
  }

  // Reading progress operations
  async getReadingProgress(userId: string, bookId: string): Promise<ReadingProgress | undefined> {
    const [progress] = await db
      .select()
      .from(readingProgress)
      .where(and(eq(readingProgress.userId, userId), eq(readingProgress.bookId, bookId)));
    return progress;
  }

  async updateReadingProgress(progress: InsertReadingProgress): Promise<ReadingProgress> {
    const [updatedProgress] = await db
      .insert(readingProgress)
      .values(progress)
      .onConflictDoUpdate({
        target: [readingProgress.userId, readingProgress.bookId],
        set: {
          ...progress,
          lastReadAt: new Date(),
        },
      })
      .returning();
    return updatedProgress;
  }

  async getCurrentlyReading(userId: string): Promise<(ReadingProgress & { book: Book })[]> {
    return db
      .select()
      .from(readingProgress)
      .innerJoin(books, eq(readingProgress.bookId, books.id))
      .where(and(eq(readingProgress.userId, userId), eq(readingProgress.isCompleted, false)))
      .orderBy(desc(readingProgress.lastReadAt));
  }

  // Review operations
  async getBookReviews(bookId: string): Promise<(Review & { user: User })[]> {
    return db
      .select()
      .from(reviews)
      .innerJoin(users, eq(reviews.userId, users.id))
      .where(eq(reviews.bookId, bookId))
      .orderBy(desc(reviews.createdAt));
  }

  async getUserReview(userId: string, bookId: string): Promise<Review | undefined> {
    const [review] = await db
      .select()
      .from(reviews)
      .where(and(eq(reviews.userId, userId), eq(reviews.bookId, bookId)));
    return review;
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    
    // Update book average rating
    const ratings = await db
      .select({ rating: reviews.rating })
      .from(reviews)
      .where(eq(reviews.bookId, review.bookId));
    
    const averageRating = ratings.reduce((sum, r) => sum + r.rating, 0) / ratings.length;
    
    await db
      .update(books)
      .set({ 
        averageRating: averageRating.toFixed(2),
        totalRatings: ratings.length,
        updatedAt: new Date()
      })
      .where(eq(books.id, review.bookId));
    
    return newReview;
  }

  async updateReview(id: string, review: Partial<InsertReview>): Promise<Review | undefined> {
    const [updatedReview] = await db
      .update(reviews)
      .set({ ...review, updatedAt: new Date() })
      .where(eq(reviews.id, id))
      .returning();
    return updatedReview;
  }

  async deleteReview(id: string): Promise<boolean> {
    const result = await db.delete(reviews).where(eq(reviews.id, id));
    return result.rowCount > 0;
  }

  // Premium subscription operations
  async getUserSubscription(userId: string): Promise<Subscription | undefined> {
    const [subscription] = await db
      .select()
      .from(subscriptions)
      .where(and(eq(subscriptions.userId, userId), eq(subscriptions.status, "active")))
      .orderBy(desc(subscriptions.createdAt));
    return subscription;
  }

  async createSubscription(subscription: InsertSubscription): Promise<Subscription> {
    const [newSubscription] = await db.insert(subscriptions).values(subscription).returning();
    
    // Update user premium status
    await db
      .update(users)
      .set({ isPremium: true, updatedAt: new Date() })
      .where(eq(users.id, subscription.userId));
    
    return newSubscription;
  }

  async updateSubscription(id: string, subscription: Partial<InsertSubscription>): Promise<Subscription | undefined> {
    const [updatedSubscription] = await db
      .update(subscriptions)
      .set(subscription)
      .where(eq(subscriptions.id, id))
      .returning();
    return updatedSubscription;
  }

  // Admin operations
  async getPendingBooks(): Promise<Book[]> {
    return db.select().from(books).where(eq(books.isApproved, false)).orderBy(desc(books.createdAt));
  }

  async getUserStats(): Promise<{ totalUsers: number; totalBooks: number; totalReviews: number }> {
    const [userCount] = await db.select({ count: count() }).from(users);
    const [bookCount] = await db.select({ count: count() }).from(books);
    const [reviewCount] = await db.select({ count: count() }).from(reviews);
    
    return {
      totalUsers: userCount.count,
      totalBooks: bookCount.count,
      totalReviews: reviewCount.count,
    };
  }
}

export const storage = new DatabaseStorage();
